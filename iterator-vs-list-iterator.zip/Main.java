/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.*;
public class Main
{
	public static void main(String[] args) {
		List<Integer>ar=new ArrayList<>();
		ar.add(10);
		ar.add(20);
		ar.add(30);
		ar.add(40);
		Iterator a=ar.iterator();
		while(a.hasNext())
		{
		System.out.print(a.next()+" ");
		}
		ListIterator t=ar.listIterator();
	
		System.out.print("Backward");
		while(t.hasPrevious())
		{
		System.out.print(t.previous()+" ");
		}
	}
}
