/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{   
    void add(int num1,int num2)
    {
      System.out.println("sum :"+(num1+num2));  
    }
    void sub(int num1,int num2)
    {
        System.out.println("difference :"+Math.abs(num1-num2));
    }

	public static void main(String[] args) 
	{
	Scanner a=new Scanner(System.in);
	int n1=a.nextInt();
	int n2=a.nextInt();
	Main m=new Main();
	m.add(n1,n2);
	Main b=new Main();
	b.sub(n1,n2);
	
	}
}
