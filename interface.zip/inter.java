
interface i1
{
 void end();
 void timer();
 
}
interface i2 
{
  void start();
  void end();
}
 class comm implements i2,i1
{
   public  void start()
    {
        System.out.println("external Requesting the call ");
    }
  public void end()
   {
        System.out.println("external Ending the call");// for common
        if(this instanceof i1)
        {
            System.out.println("call of i1 is ended");
        }
        if(this instanceof i2)
        {
            System.out.println("call of i2 is ended");
        }
        
    }
   public  void timer()
    {
        System.out.println("outofftime ");
    }
}
public class inter
{  
	public static void main(String[] args) 
	{
	comm c=new comm();
	c.start();
	c.end();
	c.timer();
	((i1)c).end();
	((i2)c).end();
	}
}
