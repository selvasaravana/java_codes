import java.util.*;
class Node 
{
    int data;
    Node next;
    Node(int data)
    {
        this.data=data;
        this.next=null;
    }
}
class linkedlist
{
    static Node insert(Node head,int data)
    {
        Node n=new Node(data);
        if(head==null)
        {  head=n;
            return n;
        }
        else
        {
            Node last=head;
            while(last.next!=null)
            {
                last=last.next;
            }
            last.next=n;
        }
        return head;
    }
    static void  display(Node head)
    {
        Node last=head;
        while(last.next!=null)
        {
            System.out.print(last.data+"->");
            last=last.next;
        }
        System.out.print(last.data);
    }
    public static void main(String[]args)
    {
        Scanner a=new Scanner(System.in);
        int n=a.nextInt();
        Node head=null;
        for(int i=0;i<n;i++)
        {
         head=insert(head,a.nextInt());
        }
        display(head);
    }
    
}