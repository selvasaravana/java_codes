abstract class merge
{
    abstract void add(int d1,int d2);
    public void mer(int d1,int d2)
    {
        System.out.println(Integer.toString(d1)+Integer.toString(d2));
    }
}
class concat extends merge
{
     void add(int d1, int d2)
    {
        System.out.println(d1+d2);
    }
}
public class abs
{
	public static void main(String[] args) {
	merge m=new concat();
	m.add(2,5);
	m.mer(2,5);
	}
}