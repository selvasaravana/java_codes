import java.util.*;
class Node 
{
    char c;
    Node left;
    Node right;
    Node(char c)
    {
        this.c=c;
        this.left=null;
        this.right=null;
    }
}
public class Binarytree
{
    static Node insert(Node root,char c)
    {
        Node n=new Node(c);
        if(root==null)
        {
            root=n;
            return root;
        }
        Queue<Node>q=new LinkedList<>();
        q.add(root);
        while(q.size()>0)
        {
            Node temp=q.remove();
            if(temp.left==null)
            {
                temp.left=n;
                return root;
            }
            if(temp.right==null)
            {
                temp.right=n;
                return root;
            }
            if(temp.left!=null&&temp.left.c!='N')
            {
                q.add(temp.left);
            }
            if(temp.right!=null&&temp.right.c!='N')
            {
                q.add(temp.right);
            }
        }
        return root;
    }
    static void inorder(Node root)
    {
        if(root==null)
        {
            return;
        }
        inorder(root.left);
        if(root.c!='N')
        {
        System.out.print(root.c+" ");
        }
        inorder(root.right);
    }
    static void preorder(Node root)
    {
        if(root==null)
        {
            return;
        }
        if(root.c!='N')
        {
         System.out.print(root.c+" ");
        }
        preorder(root.left);
       
        preorder(root.right);
    }
     static void postorder(Node root)
    {
        if(root==null)
        {
            return;
        }
        
        postorder(root.left);
       
        postorder(root.right);
        if(root.c!='N')
        {
        System.out.print(root.c+" ");
        }
    }
    static void levelorder(Node root)
    {
      if(root==null)
      {
          return;
      }
      Queue<Node>q=new LinkedList<>();
      q.add(root);
      while(q.size()>0)
      {
          Node temp=q.remove();
          if(temp.c!='N')
          {
          System.out.print(temp.c+" ");
          }
          if(temp.left!=null)
          {
              q.add(temp.left);
          }
          if(temp.right!=null)
          {
              q.add(temp.right);
          }
      }
    }
    public static void main(String[]args)
    {
        Scanner a=new Scanner(System.in);
        Node root=null;
        int n=a.nextInt();
       /* for(int i=0;i<n;i++)
        {
            root=insert(root,a.next().charAt(0));
        }
        ;*/
        for(int i=0;i<n;i++)
        {
        root=binarysearchtree(root,a.next().charAt(0));
        }
        System.out.println("Inorder traversal");
        inorder(root);
        System.out.println();
        System.out.println("preorder traversal");
        preorder(root);
         System.out.println();
        System.out.println("postorder traversal");
        postorder(root);
        System.out.println();
        System.out.println("levelorder traversal");
        levelorder(root);
      
    }
    static Node binarysearchtree(Node root,char c )
    {
        Node n=new Node(c);
        if(root==null)
        {
            root=n;
            return root;
        }
        if(c<root.c)
        {
            root.left=binarysearchtree(root.left,c);
        }
        if(c>root.c)
        {
            root.right=binarysearchtree(root.right,c);
        }
        return root;
       
        
    }
}