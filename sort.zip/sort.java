import java.util.*;
class sort
{
    static int partition(int ar[],int low,int high)
    {
        int piv=ar[high];
        int i=low,j=low;
        while(i<=high)
        {
           if(ar[i]<=piv)
           {
             int t=ar[i];
             ar[i]=ar[j];
             ar[j]=t;
             j++;
           }
           i++;
        }
        return j-1;
    }
    static void quicksort(int i,int j,int ar[])
    {
       if(i<j)
       {
           int pi=partition(ar,i,j);
           quicksort(i,pi-1,ar);
           quicksort(pi,j,ar);
       }
    }
    public static void main(String[]args)
    {
        Scanner a=new Scanner(System.in);
        int n=a.nextInt();
        int ar[]=new int[n];
        for(int i=0;i<n;i++)
        {
            ar[i]=a.nextInt();
        }
     // quicksort(0,n-1,ar);
     //mergesort(0,n-1,ar);
    // bubblesort(ar,n);
    //selectionsort(ar,n);
     insertionsort(ar,n);
     
      for(int i=0;i<n;i++)
      {
          System.out.print(ar[i]+" ");
      }
    }
    static void insertionsort(int ar[],int n)
    {
        for(int i=1;i<n;i++)
        {
            int j=i-1;
            int temp=ar[i];
            while(j>=0)
            {
               if(ar[j]>temp)
               {
                   ar[j+1]=ar[j];
               }
               else
               {
                   break;
               }
               j--;
            }
            ar[j+1]=temp;
        }
    }
    static void selectionsort(int ar[],int n)
    {
        for(int i=0;i<n;i++)
        {
            int min=i;
            for(int j=i+1;j<n;j++)
            {
              if(ar[j]<ar[min])
              {
                  min=j;
              }
            
            }
            int temp=ar[i];
            ar[i]=ar[min];
            ar[min]=temp;
            
        }
    }
    static void bubblesort(int ar[],int n)
    {
        for(int i=0;i<n;i++)
        {  int flag=0;
            for(int j=1;j<n-i;j++)
            {
            if(ar[j]<ar[j-1])
            {
              int temp=ar[j];
              ar[j]=ar[j-1];
              ar[j-1]=temp;
              flag=1;
            }
            
            }
            if(flag==0)
            {
                break;
            }
        }
    }
    static void mergesort(int i,int j,int ar[])
    {
        
    if(i<j)
    {
       
       int mid=(i+j)/2;
       mergesort(i,mid,ar);
       mergesort(mid+1,j,ar);
       merge(i,mid,j,ar);
    }
    }
    static void merge(int p,int mid,int q,int ar[])
    {
        int l[]=new int[mid+1-p];
        int r[]=new int[q-mid];
        for(int i=0;i<l.length;i++)
        {
            l[i]=ar[i+p];
        }
        for(int i=0;i<r.length;i++)
        {
            r[i]=ar[i+mid+1];
        }
        int i=0,j=0,k=p;
        while(i<l.length&& j<r.length)
        {
            if(l[i]>=r[j])
            {
               ar[k++]=r[j++]; 
            }
            else
            {
                ar[k++]=l[i++];
            }
        }
        while(i<l.length)
        {
         ar[k++]=l[i++];   
        }
        while(j<r.length)
        {
            
        ar[k++]=r[j++];
        }
    }
}