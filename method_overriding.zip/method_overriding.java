
class parent
{
    void amount(int salary)
    {
        System.out.println("Salary of parent:"+salary);
    }
}
class child extends parent 
{
    void amount(int salary)
    {
        System.out.println("Salary of children:"+salary);
    }
}
public class method_overriding
{
	public static void main(String[] args) {
	parent m=new child();
	m.amount(1000);
	
	}
}
