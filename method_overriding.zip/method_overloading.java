import java.util.*;
class expense
{
    void salary(int p1,int c1)
    {
        System.out.print("total salary"+p1+c1);
    }
    void salary(int p1)
    {
        System.out.print("parents salary "+p1);
    }
    
}
public class method_overloading
{
    
    public static void main(String[]args)
    {
        Scanner a=new Scanner(System.in);
        int amount =a.nextInt();
        expense e=new expense();
        e.salary(amount);
        
    }
}