/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
	int ar[]={1,3,4,5,7};
	int key=7;
	 int low=0;
	 int high=ar.length-1;
	while(true)
	{
	    int mid=(low+high)/2;
	    if(key==ar[mid])
	    {
	        System.out.println(mid);
	        break;
	    }
	    if(key>ar[mid])
	    {
	         low=mid+1;
	    }
	    if(key<ar[mid])
	    {
	        high=mid-1;
	    }
	}
	}
}
